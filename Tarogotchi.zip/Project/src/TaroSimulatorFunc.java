import java.awt.Color;

public class TaroSimulatorFunc {
	
	static float soilWater = 0.5f;			//assigns a float variable called soilWater a starting value of 0.5f
	static float fertilizer = 0.5f;			//assigns a float variable called fertilizer a starting value of 0.5f
	static float plantGrowth = 0.1f;		//assigns a float variable called plantGrowth a starting value of 0.1f
	static float plantHealth = 1.0f;		//assigns a float variable called plantHealth a starting value of 1
	
	static int CursorX = 0;					//sets up the location of the mouse pointer in the x direction
	static int CursorY = 0;					//sets up the location of the mouse pointer in the y direction
	
	static float plantWidth = 0.0f;			//assigns a float variable called plantWidth a starting value of 0.0f
	static float plantHeight = 0.0f;		//assigns a float variable called plantHeight a starting value of 0.0f
	
	static EZText waterAmount;				//creates an EZText variable called waterAmount
	static EZText manureAmount;				//creates an EZText variable called manureAmount
	static EZText healthAmount;				//creates an EZText variable called healthAmount
	
	static EZImage startBackground;			//creates an EZImage variable called startBackground
	static EZImage inGameBackground;		//creates an EZImage variable called inGameBackground
	static EZImage waterCan;				//creates an EZImage variable called waterCan
	static EZImage manureBarrel; 			//creates an EZImage variable called manureBarrel
	static EZImage Button3;					//creates an EZImage variable called Button3 (for deBUGging)
	static EZImage waterDrop;				//creates an EZImage variable called waterDrop
	static EZImage poop;					//creates an EZImage variable called poop
	static EZImage taroVector;				//creates an EZImage variable called teroVector
	static EZImage BSOW;					//creates an EZImage variable called BSOW
	static EZImage BSOD;					//creates an EZImage variable called BSOD
	
	static Color stemColor;					//creates a color variable called stemColor
	
	static EZRectangle stem;				//creates an EZRectangle variable called stem
	
	static EZSound poopSound;				//creates an EZSound variable called poopSound
	static EZSound waterSound;				//creates an EZSound variable called waterSound
	static EZSound victory;					//creates an EZSound variable called victory
	static EZSound defeat;					//creates an EZSound variable called defeat
	
	static long startTime;					//creates a long variable called startTime
	static long currentTime;				//creates a long variable called currentTime
	
	public static void EZSetup() {			//this will be used to set up our program (images, sounds, etc.)
		
		EZ.initialize(700, 500);												//creates a 700 x 500 window (in pixels)
		
		inGameBackground = EZ.addImage("Background.png", 350, 250);				//creates the background in-game
		waterCan = EZ.addImage("WaterCan.png", 560, 400);						//creates the water can button
		manureBarrel = EZ.addImage("ManureVector.png", 150, 400); 				//creates the fertilizer button
		waterDrop = EZ.addImage("WaterVector.png", 560, 150);					//creates the water indicator
		poop = EZ.addImage("Poop.png", 150, 150);								//creates the fertilizer indicator
		//Button3 = EZ.addImage("bug.png", 150, 250);							just for deBUGging
		
		waterAmount = EZ.addText(560, 475, "" + soilWater, Color.BLACK, 18);	//shows starting value of water in the program
		manureAmount = EZ.addText(150, 475, "" + fertilizer, Color.BLACK, 18);	//shows starting value of fertilizer in the program
		healthAmount = EZ.addText(350, 475, "" + plantHealth, Color.BLACK, 18);	//shows starting value of health in the program
		
		stem = EZ.addRectangle(250, 500, 0, 0, stemColor, true);				//creates the stem of the taro plant
		taroVector = EZ.addImage("TaroVector.png", 350, 700);					//adds the picture of the taro leaf
		
		poopSound = EZ.addSound("Poop.wav");									//adds sound to the variable poopSound
		waterSound = EZ.addSound("Water.wav");									//adds sound to the variable waterSound
		victory = EZ.addSound("Win.wav");										//adds sound to the variable victory
		defeat = EZ.addSound("CriticalError.wav");								//adds sound to the variable defeat
		
		startTime = System.currentTimeMillis();									//records starting time once the program runs
	}
	
	public static void EZClick() {
		CursorX = EZInteraction.getXMouse();		//gets the x coordinate of the mouse pointer
		CursorY = EZInteraction.getYMouse();		//gets the y coordinate of the mouse pointer
		
		currentTime = System.currentTimeMillis();
		
		if (EZInteraction.wasMouseLeftButtonReleased()) {
			
			if (waterCan.isPointInElement(CursorX, CursorY)) {	
				soilWater += 0.3f;											//if waterCan is clicked, then soilWater increases by 0.3		
				waterSound.play();											//water.wav also plays when clicked
				waterAmount.setMsg("" + soilWater);							//this will show the amount of water in the program
				//System.out.println("Soil Water: " + soilWater);			just for deBUGging			
			}
			if (manureBarrel.isPointInElement(CursorX, CursorY)) {	
				fertilizer += 0.3f;											//if manureBarrel is clicked, then fertilizer increases by 0.3
				poopSound.play();											//poop.wav also plays when clicked
				manureAmount.setMsg("" + fertilizer);						//this will show the amount of water in the program
				//System.out.println("Fertilizer: " + fertilizer);			just for deBUGging
			}
			/*														____
			if (Button3.isPointInElement(CursorX, CursorY)) {			|
				System.out.println("soilWater: " + soilWater);			|
				System.out.println("fertilizer: " + fertilizer);		|------> just for deBUGging purposes; when the bug picture
				System.out.println("plantHealth: " + plantHealth);		|		is clicked, it shows the amount of soilWater, fertilizer,
				System.out.println("plantGrowth: " + plantGrowth);		|		plantHealth, and plantGrowth on the console
			}														____|
			*/
		}
	}

	public static void EZTime() {
		if ((currentTime - startTime) > 1000) {					//checks if 1 second has passed
			
			//================================|below this comment line are codes for soilWater|=======================================
			
			soilWater = soilWater - plantGrowth*0.05f;			//soilWater decreases as a function of growth * 0.05f
			soilWater -= 0.001f;								//evaporation decreases soilWater by 0.001f
			soilWater = soilWater - fertilizer*0.5f;			//soilWater decreases as a function of fertilizer * 0.5f
			
			if (soilWater < 0) {	
				soilWater = 0.0f;								//keeps soilWater from going negative
			}
			if (soilWater == 0) {
				plantHealth -= 0.02f;							//if soilWater reaches 0, then plantHealth decreases by 0.02
			}
			if (soilWater > 1.0999) {	
				plantHealth -= 0.03f; 							//if soilWater goes over 1, then plantHealth decreases by 0.03
			}
			
			//================================|below this comment line are codes for fertilizer|======================================
			
			fertilizer = fertilizer - plantGrowth*0.05f;		//fertilizer decreases as a function of growth * 0.05f
			fertilizer -= 0.001f;								//fertilizer decreases by 0.001f
			
			if (fertilizer < 0) {
				fertilizer = 0.0f;								//keeps fertilizer from going negative
			}
			if (fertilizer == 0) {								//if fertilizer is 0 then plantHealth will decrease by 0.01
				plantHealth -= 0.01f;
			}
			if (fertilizer > 1.0999) {							//if fertilizer is approximately over 1, then plantHealth will decrease b 0.02
				plantHealth -= 0.02f;
			}
			
			//=========================|below this comment line are codes for plantHealth and plantGrowth|==============================
			
			plantHealth += 0.02f;								//plantHealth increases by 0.02 each second
			if (plantHealth < 0) {								//plantHealth cannot be negative since we will be using this to dictate the
				plantHealth = 0;								//color of the plant and RGB values cannot go negative
			}
			plantGrowth = plantGrowth + plantHealth*0.001f;		//plant grows based on plantHealth multiplied by 0.001
			
			healthAmount.setMsg("" + plantHealth);				//shows health of the plant in the program
			
			//=========================|below this comment line are codes for the stem of the plant|====================================
			
			plantHeight = plantGrowth * 150;						//height of the plant has to be declared as plantGrowth multiplied by 150
			stem.setWidth((int)(plantGrowth*50));					//width also increases as plantGrowth increases but multiplied only by 50
			stem.setHeight((int)(plantHeight));						//height of the plant grows as plantGrowth increases multiplied by 150
			stem.translateTo(350, (450-(int)plantHeight/2));		//stem has to be translated otherwise the stem grows on both top and bottom
			taroVector.translateTo(350, (450-(int)plantHeight));	//the taro leaf also has to be translated to the top of the stem
			taroVector.scaleTo(plantGrowth*2);						//the taro leaf should grow as well
			
			//=========================|below this comment line are codes for the color of the plant|===================================
			
			int r = 200 - ((int)(200*plantHealth));				//R in RGB is set to 200, then subtracted based on plantHealth*200
			if (r < 0) {										//r should not go negative, otherwise program crashes (no negatives in RGB) 
				r = 0;
			}
			if (r > 140) {										//r should be restricted to not lower than 140 in order to get color brown
				r = 140;
			}
			stemColor = new Color(r, 200-r, 0);					//creates the color of the stem; as r increases, the stem will slowly go brown
			stem.setColor(stemColor);							//sets the color of the stem in the window
			
			//==================================|below this comment line are codes for HUD|=============================================
			
			waterDrop.scaleTo(1+soilWater);				//scales waterDrop and poop relative to the amount of soilWater and fertilizer
			poop.scaleTo(1+fertilizer);					//1 is added so that the base scale will always be 1 when soilWater and fertilizer are 0
			
			//==========================================================================================================================
			startTime = currentTime;							//resets the time
		}
	}
	
	public static void EZVictory() {							//displays image and plays sound when player wins
		BSOW = EZ.addImage("BSOW.png", 350, 250);
		victory.play();
	}
	
	public static void EZDefeat() {								//displays image and plays sound when player loses
		BSOD = EZ.addImage("BSOD.png", 350, 250);
		defeat.play();
	}
	
	public static void main(String[] args) {			//main function

		EZSetup();										//uses EZSetup function
		
		while (true) {									//needed to keep the game running (infinite loop)
			
			EZClick();									//uses EZClick function
			EZTime();									//uses EZTime function
			
			if (plantGrowth >= 1) {						//if plantGrowth is reaches 1, then the player wins
				EZVictory();							//uses EZVictory function
				break;									//ends while loop
			} else if (plantHealth == 0) {				//if plantHealth reaches 0, then the player loses
				EZDefeat();								//uses EZDefeat function
				break;									//ends while loop
			}
						
			EZ.refreshScreen();							//needed to keep the game running
			
		}

	}

}
